user_pref("browser.safebrowsing.downloads.enabled",                 true);
user_pref("browser.safebrowsing.downloads.remote.block_potentially_unwanted",                 true);
user_pref("browser.safebrowsing.downloads.remote.enabled",	true);
user_pref("browser.safebrowsing.downloads.remote.block_dangerous",            true);
user_pref("browser.safebrowsing.downloads.remote.block_dangerous_host",       true);
user_pref("browser.safebrowsing.downloads.remote.block_uncommon",                 true);

user_pref("dom.disable_open_during_load", true);
user_pref("app.update.auto",                 true);
user_pref("browser.safebrowsing.phishing.enabled",		true);
user_pref("browser.safebrowsing.malware.enabled",		true);
user_pref("browser.contentblocking.category", "strict");