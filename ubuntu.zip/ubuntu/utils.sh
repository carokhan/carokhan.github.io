#!/bin/bash

ask () {
	if [[ $2 -eq 1 ]]
	then
		log "$1""?" $2 $3
		CHOICE=$(gum choose "✓" "x")
		if [[ "$CHOICE" == "✓" ]]
		then
			return 1
		else
			return 0
		fi
	else
		read -p "$1? (y/n) " -n 1 -r
		echo
		if [[ ! $REPLY =~ ^[Yy]$ ]] | [[ !$REPLY = '' ]]
		then
			return 1
		else
			return 0
		fi
	fi

}


beautify () {
	if ask "Beautify"
	then
		home=("/home/""$(logname)")
		echo FOREGROUND='006' > "$home""/ubuntu/gum.config"
		source "$home""/ubuntu/gum.config"
		which gum
		if [[ $? -eq 1 ]]
		then
			sudo apt-get install curl -y
			sudo mkdir -p /etc/apt/keyrings
			curl -fsSL https://repo.charm.sh/apt/gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/charm.gpg --yes
			echo "deb [signed-by=/etc/apt/keyrings/charm.gpg] https://repo.charm.sh/apt/ * *" | sudo tee /etc/apt/sources.list.d/charm.list
			sudo apt-get update -y
			sudo apt-get install gum -y
		fi
		
		gum style --foreground="$FOREGROUND" "Gum initialized!"
		echo
		return 1
	else
		return 0
	fi	
}


log () {
	if [[ $2 -eq 1 ]]
	then
		home=("/home/""$(logname)")
		source "$home""/ubuntu/gum.config"
		if [[ $3 -eq 1 ]]
		then
			gum style "$1" --foreground="$FOREGROUND" --bold
		else
			gum style "$1" --foreground="$FOREGROUND"
		fi
	else
		echo "$1"
	fi
}