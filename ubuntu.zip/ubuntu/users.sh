#!/bin/bash
badadmins () {
	log "Removing bad admins!" $1

	readarray -t admins < <(sudo groupmems -g sudo -l | awk '{OFS="\n"; $1=$1}1' | sort)
	readarray -t saved < "$home""/admins"

	for i in "${saved[@]}"
	do
		admins=(${admins[@]//*$i*})
	done

	for admin in "${admins[@]}"
	do
		admin=${admin##*/}
		ask "Found unauthorized admin: ""$admin"". Remove" $1
		if [[ $? -eq 1 ]]
		then
			sudo deluser $admin sudo
			log "Removed admin access from ""$admin" $1
		fi
		echo
	done
}

badusers () {
	log "Deleting bad users!" $1

	users=()
	for user in $(find /home/ -mindepth 1 -maxdepth 1 -type d)
	do
		if [[ $user != "/home/"$(logname) ]]
		then
			users+=("$user")
		fi
	done

	readarray -t saved < "$home""/users"
	for i in "${saved[@]}"
	do
		users=(${users[@]//*$i*})
	done

	for user in "${users[@]}"
	do
		user=${user##*/}
		ask "Found unauthorized user: ""$user"". Remove" $1
		if [[ $? -eq 1 ]]
		then
			sudo deluser $user --remove-home
			log "Deleted ""$user" $1
		fi
		echo
	done
}

passwords () {
	log "Changing all passwords!" $1
	users=$(ls /home)
	for user in $users
	do
		if [[ $user != $(logname) ]]
		then
			pass=$(tr -dc 'A-Za-z0-9!"#$%&'\''()*+,-./:;<=>?@[\]^_`{|}~' </dev/urandom | head -c 13)
    		log "Changing password for "$user" to "$pass $1
			echo "$user:$pass" | chpasswd 
		else
			log "Skipping current user "$(logname)" (root)." $1
		fi
	done
}

files () {
	log "Removing all ""$1""s!" $2
	find /home -type f -name "$1"
	find /home -type f -name "$1" -delete
}

passpolicy () {
	log "Configuring password policy!" $1
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	cp "/etc/login.defs" "$home""/ubuntu/old_configs/login.defs.old"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/login.defs.old"

	sudo sed -i '/^PASS_MAX_DAYS/ c\PASS_MAX_DAYS   30' /etc/login.defs
	sudo sed -i '/^PASS_MIN_DAYS/ c\PASS_MIN_DAYS   7'  /etc/login.defs
	sudo sed -i '/^PASS_WARN_AGE/ c\PASS_WARN_AGE   7' /etc/login.defs
	sudo sed -i '/^LOGIN_RETRIES/ c\LOGIN_RETRIES   3' /etc/login.defs
	sudo sed -i '/^LOGIN_TIMEOUT/ c\LOGIN_TIMEOUT   30' /etc/login.defs
	sudo sed -i '/^ENCRYPT_METHOD/ c\ENCRYPT_METHOD   SHA512`' /etc/login.defs

	users=$(ls /home)
	for user in $users
	do
		if [[ $user != $(logname) ]]
		then
    		sudo chage -m 7 -M 30 -I 7 -E 7 $user
    		sudo chage -E -1 $user
		else
			log "Skipping current user "$(logname)" (root)." $1
		fi
	done
}