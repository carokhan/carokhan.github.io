#!/bin/bash

if [ "$EUID" -ne 0 ]
then 
  echo "Run as root!"
  exit
fi

sudo apt-get update -y
sudo apt-get install --only-upgrade ca-certificates -y

GUM_ACTIVE=0

dpkg -s moreutils > /dev/null 2>/dev/null
if [[ $? -eq 1 ]]
then
	sudo apt-get install moreutils -y
fi

home=("/home/""$(logname)")
[ -f "/home/""$(logname)""/ubuntu/script.log" ] && rm "/home/""$(logname)""/ubuntu/script.log"
exec > >(tee >(ts >> "$home""/ubuntu/script.log")) 2>&1

dpkg -s lolcat > /dev/null 2>/dev/null
if [[ $? -eq 1 ]]
then
	sudo apt-get install lolcat -y
fi

dpkg -s curl  > /dev/null 2>/dev/null
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install curl -y
	fi

dpkg -s wget  > /dev/null 2>/dev/null
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install wget -y
	fi

echo -ne "H4sICNAkVmMAA3NlbnRyeQBVzrEKhEAMBNDerxhstsqkj/gnAbc5uMpCrznYj3dE0HVSBB5kCHkHtHE0Dg/AZUZkZ65R8oVNo2i98Wp8EO5eGQrrfY/WGiJUmxGYOp7EuSzes77JRDk7CnzYP+tv+3P/os4ljLRSD1sr9hvUAAAA" | base64 -d | gunzip | /usr/games/lolcat -f -F 0.2 -a -s 200 -S 1
media=("*.mp3" "*.mp4")
prohibited=("hashcat minetest fcrackzip frostwire vuze-vs wfuzz dirbuster gobuster ncrack smbmap impacket aircrack-ng dsniff knocker tshark medusa tomcat mariadb-server pure-ftpd gameconqueror manaplus nmap hydra hydra-gtk nmapsi4 deluge pumpa zangband amule icecast2 postfix pompem goldeneye packit themole shattered-pixel-dungeon opensmtpd spice-vdagent pptp nginx zmap osquery ncrack 4g8 sqlmap postgresql kismet freeciv apache2 wireshark samba john ophcrack")

source "$home""/ubuntu/utils.sh"

beautify Beautify GUM_ACTIVE
GUM_ACTIVE=$?

echo FOREGROUND='177' > "$home""/ubuntu/gum.config"

ask "Audit unauthorized admins" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='170' > "$home""/ubuntu/gum.config"

	source "$home""/ubuntu/users.sh"
	badadmins GUM_ACTIVE

	echo FOREGROUND="162" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving unauthorized admins" GUM_ACTIVE 1
fi

ask "Audit unauthorized users" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='160' > "$home""/ubuntu/gum.config"

	source "$home""/ubuntu/users.sh"
	badusers GUM_ACTIVE

	echo FOREGROUND="196" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving unauthorized users" GUM_ACTIVE 1
fi

ask "Change passwords" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='209' > "$home""/ubuntu/gum.config"

	source "$home""/ubuntu/users.sh"
	passwords GUM_ACTIVE

	echo
	echo FOREGROUND="210" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving passwords" GUM_ACTIVE 1
fi

ask "Enable firewall" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='216' > "$home""/ubuntu/gum.config"

	log "Enabling ufw!" GUM_ACTIVE
	dpkg -s ufw  > /dev/null 2>/dev/null
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install ufw -y
	fi
	sudo ufw enable
	sudo iptables -P FORWARD DROP
	systemctl status ufw.service -n 0

	echo
	echo FOREGROUND="221" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving firewall" GUM_ACTIVE 1
fi

ask "Fix update settings" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='228' > "$home""/ubuntu/gum.config"

	log "Configuring update settings!" GUM_ACTIVE
	sudo cp -r "$home""/ubuntu/configs/apt.conf.d" "/etc/apt/"

	echo
	echo FOREGROUND="190" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving update settings" GUM_ACTIVE 1
fi

ask "Update packages" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='154' > "$home""/ubuntu/gum.config"

	log "Updating packages!" GUM_ACTIVE
	sudo apt-get update -y
	sudo apt-get upgrade -y

	echo
	echo FOREGROUND="119" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving updates" GUM_ACTIVE 1
fi

for type in ${media[@]}
do
	ask "Remove ""$type""s" GUM_ACTIVE 1
	if [[ $? -eq 1 ]]
	then
		home=("/home/""$(logname)")
		echo FOREGROUND='121' > "$home""/ubuntu/gum.config"

		source "$home""/ubuntu/users.sh"
		files $type GUM_ACTIVE

		echo
		echo FOREGROUND="123" > "$home""/ubuntu/gum.config"
	else
		echo
		log "Leaving ""$type""s" GUM_ACTIVE 1
	fi
done

ask "Configure Firefox" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='117' > "$home""/ubuntu/gum.config"

	log "Configuring Firefox!" GUM_ACTIVE
	cp "$home""/ubuntu/configs/user.js" "$home"/.mozilla/firefox/*.default-release/

	echo
	echo FOREGROUND="111" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving Firefox settings" GUM_ACTIVE 1
fi

ask "Disable ssh root login" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='105' > "$home""/ubuntu/gum.config"

	log "Disabling SSH root login!" GUM_ACTIVE
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	cp "/etc/ssh/sshd_config" "$home""/ubuntu/old_configs/sshd_config.old"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/sshd_config.old"

	sed -i '/^'"PermitRootLogin "'/d' "/etc/ssh/sshd_config"
	echo "PermitRootLogin no" >> "/etc/ssh/sshd_config"

	echo
	echo FOREGROUND="033" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving ssh root login" GUM_ACTIVE 1
fi

ask "Remove prohibited packages" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	for package in ${prohibited[@]}
	do
		dpkg -s $package > /dev/null 2>/dev/null
		if [[ $? -eq 0 ]]
		then
			home=("/home/""$(logname)")
			echo FOREGROUND='039' > "$home""/ubuntu/gum.config"

			ask "Found prohbited package: ""$package"". Remove" GUM_ACTIVE
			if [[ $? -eq 1 ]]
			then
				sudo apt-get purge $package -y
			else
				log "Leaving ""$package" GUM_ACTIVE
			fi

			echo
			echo FOREGROUND="045" > "$home""/ubuntu/gum.config"
		fi
	done
	sudo apt-get autoremove -y --purge
else
	echo
	log "Leaving packages" GUM_ACTIVE 1
fi

ask "Configure PAM" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='051' > "$home""/ubuntu/gum.config"

	log "Configuring PAM!" GUM_ACTIVE
	dpkg -s libpam-pwquality > /dev/null 2>/dev/null
	
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install libpam-pwquality
	fi
	
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	cp "/etc/pam.d/common-password" "$home""/ubuntu/old_configs/common-password.old"
	sudo cp "$home""/ubuntu/configs/common-password" "/etc/pam.d/common-password"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/common-password.old"

	echo
	echo FOREGROUND="081" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving PAM" GUM_ACTIVE 1
fi

ask "Configure password policy" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='062' > "$home""/ubuntu/gum.config"

	passpolicy GUM_ACTIVE

	echo
	echo FOREGROUND="105" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving password algorithm" GUM_ACTIVE 1
fi

ask "Disable root" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='99' > "$home""/ubuntu/gum.config"

	log "Disabling root!" GUM_ACTIVE
	sudo passwd -l root

	echo
	echo FOREGROUND="093" > "$home""/ubuntu/gum.config"
else
	log "Leaving root account" GUM_ACTIVE 1
fi

ask "Require password for sudo" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='129' > "$home""/ubuntu/gum.config"

	log "Requiring password to use sudo!" GUM_ACTIVE
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	sudo cp "/etc/sudoers" "$home""/ubuntu/old_configs/sudoers.old"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/sudoers.old"
	sudo sed -i '/NOPASSWD/d' /etc/sudoers

	echo
	echo FOREGROUND="135" > "$home""/ubuntu/gum.config"
else
	log "Leaving sudo password requirements" GUM_ACTIVE 1
fi

ask "Enable logging" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='177' > "$home""/ubuntu/gum.config"

	log "Enabling rsyslog!" GUM_ACTIVE
	dpkg -s rsyslog  > /dev/null 2>/dev/null
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install rsyslog -y
	fi
	sudo systemctl enable rsyslog
	sudo systemctl restart rsyslog
	systemctl status rsyslog.service -n 0

	echo
	echo FOREGROUND="171" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving logging" GUM_ACTIVE 1
fi

ask "Disable ICMP echo requests for UFW" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='165' > "$home""/ubuntu/gum.config"

	log "Disabling ICMP echo requests for UFW" GUM_ACTIVE
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	sudo cp /etc/ufw/before.rules "$home""/ubuntu/old_configs/before.rules.old"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/before.rules.old"
	sudo cp "$home""/ubuntu/configs/before.rules" "/etc/ufw/before.rules"

	echo
	echo FOREGROUND="207" > "$home""/ubuntu/gum.config"
else
	log "Leaving sudo password requirements" GUM_ACTIVE 1
fi

ask "Install antivirus" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='222' > "$home""/ubuntu/gum.config"

	log "Enabling ClamAV!" GUM_ACTIVE
	dpkg -s clamav  > /dev/null 2>/dev/null
	if [[ $? -eq 1 ]]
	then
		sudo apt-get install clamav clamtk -y
	fi
	systemctl status clamav-freshclam.service -n 0

	echo
	echo FOREGROUND="201" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving antivirus" GUM_ACTIVE 1
fi

ask "Configure authentication" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='206' > "$home""/ubuntu/gum.config"

	log "Configuring authentication!" GUM_ACTIVE
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	cp "/etc/pam.d/common-auth" "$home""/ubuntu/old_configs/common-auth.old"
	sudo cp "$home""/ubuntu/configs/common-auth" "/etc/pam.d/common-auth"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/common-auth.old"

	echo
	echo FOREGROUND="199" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving authentication" GUM_ACTIVE 1
fi

ask "Configure networking" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	home=("/home/""$(logname)")
	echo FOREGROUND='204' > "$home""/ubuntu/gum.config"

	log "Configuring networking!" GUM_ACTIVE
	[ ! -d "/home/""$(logname)""/ubuntu/old_configs" ] && mkdir "$home""/ubuntu/old_configs/"
	sudo chown $(logname) "$home""/ubuntu/old_configs"
	cp "/etc/sysctl.conf" "$home""/ubuntu/old_configs/sysctl.conf.old"
	sudo cp "$home""/ubuntu/configs/sysctl.conf" "/etc/sysctl.conf"
	sudo chown "$(logname)" "$home""/ubuntu/old_configs/sysctl.conf.old"

	echo
	echo FOREGROUND="202" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving networking" GUM_ACTIVE 1
fi


ask "Download Linpeas" GUM_ACTIVE 1
if [[ $? -eq 1 ]]
then
	if [ ! -f "/home/""$(logname)""/ubuntu/other/linpeas.sh" ]
	then
		home=("/home/""$(logname)")
		echo FOREGROUND='208' > "$home""/ubuntu/gum.config"
		[ ! -d "/home/""$(logname)""/ubuntu/other" ] && mkdir "$home""/ubuntu/other"
		sudo chown "$(logname)" "$home""/ubuntu/other"
		sudo chown $(logname) "$home""/ubuntu/old_configs"
		wget "https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh" -O "$home""/ubuntu/other/linpeas.sh"
		sudo chown "$(logname)" "$home""/ubuntu/other/linpeas.sh"
		chmod +x "$home""/ubuntu/other/linpeas.sh"
		log "Stored at ~/ubuntu/other/linpeas.sh" GUM_ACTIVE
	else
		log "Linpeas already installed at ~/ubuntu/other/linpeas.sh" GUM_ACTIVE
	fi

	echo
	echo FOREGROUND="215" > "$home""/ubuntu/gum.config"
else
	echo
	log "Leaving networking" GUM_ACTIVE 1
fi

log "Reminders:" GUM_ACTIVE 1
log "1. Hidden users (uid below 1000)" GUM_ACTIVE
log "2. Service-specific configs in README" GUM_ACTIVE
log "3. More SSH settings (check Roman checklist)" GUM_ACTIVE
log "4. Linpeas!" GUM_ACTIVE
log "5. Backdoors" GUM_ACTIVE
log "6. More packages/services" GUM_ACTIVE

sudo sed -i "s/\x1b\[[0-9;]*m//g" "$home""/ubuntu/script.log"
sudo chown "$(logname)" "$home""/ubuntu/script.log"